import boto3
import json

def lambda_handler(event, context):
    if event:
        file_obj = event['Records'][0]
        
        s3 = boto3.client('s3')
        # Get neccesarry info ex) bucket name, file name, region, account # and so on ------------------------
        bucket_name =  file_obj['s3']['bucket']['name']
        file_name = file_obj['s3']['object']['key']
                
        fileObj = s3.get_object(Bucket=bucket_name, Key=file_name)
        file_content = fileObj['Body'].read().decode('utf-8')
        
        # Remove unnecessary spaces
        file_content + 'THIS HAS BEEN ADDED TO'

        new_file_name = file_name + '-transformed'
        
        # Put result to the new object and the target bucket
        s3.put_object(Body=', '.join(file_content), Bucket=bucket_name, Key=new_file_name)
